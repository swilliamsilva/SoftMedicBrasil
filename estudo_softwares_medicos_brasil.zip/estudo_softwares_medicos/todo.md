# Lista de Tarefas: Softwares Médico-Hospitalares no Brasil

- [X] Pesquisar softwares médico-hospitalares disponíveis no Bra- [X] Coletar informações detalhadas sobre aplicações e desempenho dos softwares identificad- [X] Levantar dados de custos e modelos de serviço para cada software.
- [ ] Comparar os softwares com base nas informações recolhidas (aplicações, desempenho, custo, serviço).
- [X] Validar a confiabilidade dos dados coletados.
- [ ] Elaborar um relatório comparativo detalhado em formato de prosa contínua.
- [ ] Enviar o relatório final ao usuário.
